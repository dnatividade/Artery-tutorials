#ifndef GEOPOSITION_H_W4MLBSNL
#define GEOPOSITION_H_W4MLBSNL

namespace traci
{

struct TraCIGeoPosition
{
    double longitude;
    double latitude;
};

} // namespace traci

#endif /* GEOPOSITION_H_W4MLBSNL */

