These sources are copied from SUMO 1.9.0.
SUMO is licensed under [Eclipse Public License v2.0](http://www.eclipse.org/legal/epl-v20.html).

Please refer to the [SUMO Wiki](http://sumo.dlr.de/wiki) for a more information about SUMO and TraCI.
