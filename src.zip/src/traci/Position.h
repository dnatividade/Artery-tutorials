#ifndef POSITION_H_ECOTFZI7
#define POSITION_H_ECOTFZI7

#include "traci/sumo/utils/traci/TraCIAPI.h"

namespace traci
{

using libsumo::TraCIPosition;

} // namespace traci

#endif /* POSITION_H_ECOTFZI7 */

