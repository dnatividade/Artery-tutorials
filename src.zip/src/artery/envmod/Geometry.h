/*
 * Artery V2X Simulation Framework
 * Copyright 2014-2017 Hendrik-Joern Guenther, Raphael Riebl, Oliver Trauer
 * Licensed under GPLv2, see COPYING file for detailed license and warranty terms.
 */

#ifndef ENVMOD_GEOMETRY_H_VKGEIFYB
#define ENVMOD_GEOMETRY_H_VKGEIFYB

#include "artery/utility/Geometry.h"

#endif /* ENVMOD_GEOMETRY_H_VKGEIFYB */

