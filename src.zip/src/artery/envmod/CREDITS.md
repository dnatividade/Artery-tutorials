Artery's environment model in its initially published version includes contributions from (in alphabetical order):

- Nico Brüttner <nbruettn@ibr.cs.tu-bs.de>
- Hendrik-Jörn Günther <hguenther@ibr.cs.tu-bs.de>
- Deepak Patel <deepak.patel@volkswagen.com>
- Raphael Riebl <raphael.riebl@thi.de>
- Oliver Trauer <oliver.trauer@c4cengineering.de>
